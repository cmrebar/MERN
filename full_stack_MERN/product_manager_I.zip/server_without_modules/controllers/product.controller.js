const Product = require("../models/product.model");

module.exports.createNewProduct = (request, response) => {
    Product.create(request.body)
        .then(newlyCreatedProduct => response.json({ product: newlyCreatedProduct }))
        .catch(err => response.json({ message: "Something went wrong", error: err }));
}

module.exports.findAllProducts = (request, response) => {
    Product.find({})
        .then(allProducts => response.json({ products: allProducts }))
        .catch(err => response.json({ message: "Something went wrong", error: err }));
}