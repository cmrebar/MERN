import './App.css';
import PersonCard from './components/PersonCard'

function App() {
  return (
    <div className="App">
      <PersonCard firstName={ 'Bob' } lastName={ 'the Builder' } age={ '36' } hairColor={ 'brown' } />
      <PersonCard firstName={ 'Spongebob' } lastName={ 'Squarepants' } age={ '50' } hairColor={ 'none' } />
      <PersonCard firstName={ 'Danny' } lastName={ 'Phantom' } age={ '14' } hairColor={ 'white' } />
      <PersonCard firstName={ 'Timmy' } lastName={ 'Turner' } age={ '11' } hairColor={ 'brown' } />
    </div>
  );
}

export default App;
