import React, { useState } from 'react';

const PersonCard = props => {
    const {firstName, lastName, age, hairColor} = props;

    const [state, setState] = useState({
        age: age
    });

    const handleClick = () => {
        setState({
            age: Math.trunc(state.age) + 1
        });
    }
    
    return (
        <div>
            <h1>
                {lastName}, {firstName}
            </h1>
            <h4>
                Age: {state.age}
            </h4>
            <h4>
                Hair Color: {hairColor}
            </h4>
            <button onClick={handleClick}>Birthday button for { firstName } { lastName }</button>
        </div>
    )
}
export default PersonCard